#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Генерирует n8n-workflow.json (RSS → бесплатная LLM → HTML/Markdown → Telegram)."""
import json, os

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "n8n-ai-digest.json")

FEEDS = [
    ("TechCrunch AI",    "https://techcrunch.com/category/artificial-intelligence/feed/",        320),
    ("Hugging Face",     "https://huggingface.co/blog/feed.xml",                                 580),
    ("GitHub Trending",  "https://mshibanami.github.io/GitHubTrendingRSS/daily/all.xml",          840),
    ("Habr AI",          "https://habr.com/ru/rss/hubs/artificial_intelligence/",                 1100),
    ("OpenAI",           "https://openai.com/news/rss.xml",                                      1360),
]

SCHEDULE = {
    "parameters": {
        "rule": {"interval": [{"field": "hours", "hoursInterval": 3}]}
    },
    "id": "11111111-1111-4111-8111-111111111111",
    "name": "Каждые 3 часа",
    "type": "n8n-nodes-base.scheduleTrigger",
    "typeVersion": 1.2,
    "position": [-460, 300],
}

AGG_CODE = r"""// ── Собираем все ленты в один список: дедуп + фильтр по свежести ──
const HOURS = 26;          // окно «свежести»
const MAX_ITEMS = 20;      // сколько отдаём в LLM (экономит токены)
const since = Date.now() - HOURS * 3600 * 1000;

const seen = new Set();
const keep = [];

const pick = (o, keys) => { for (const k of keys) { if (o?.[k]) return o[k]; } return ''; };
const clean = s => String(s || '')
  .replace(/<[^>]+>/g, ' ')
  .replace(/&[a-z]+;/gi, ' ')
  .replace(/\s+/g, ' ')
  .trim()
  .slice(0, 240);

for (const item of $input.all()) {
  const j = item.json || {};
  const title = clean(pick(j, ['title']));
  const link = String(pick(j, ['link', 'guid', 'id'])).trim();
  if (!title || !/^https?:/.test(link)) continue;

  const key = link.split('?')[0].replace(/\/+$/, '').toLowerCase();
  if (seen.has(key)) continue;

  const rawDate = pick(j, ['isoDate', 'pubDate', 'published', 'updated', 'date']);
  const ts = rawDate ? new Date(rawDate).getTime() : 0;
  if (ts && ts < since) continue;          // старое не берём

  seen.add(key);
  keep.push({
    title,
    link,
    ts,
    desc: clean(pick(j, ['contentSnippet', 'content', 'summary', 'description'])),
  });
}

keep.sort((a, b) => b.ts - a.ts);
const top = keep.slice(0, MAX_ITEMS);

if (!top.length) {
  return [{ json: { empty: true, listing: '', count: 0,
    date: new Date().toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' }) } }];
}

const listing = top.map((x, i) => `${i + 1}. ${x.title}\n${x.desc}`).join('\n\n');

return [{
  json: {
    count: top.length,
    listing,
    date: new Date().toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' }),
    items: top,
  },
}];
"""

LLM_SYSTEM = (
    "Ты — редактор ежедневного дайджеста новостей об искусственном интеллекте для "
    "русскоязычной аудитории (разработчики и интересующиеся ИИ).\n"
    "По списку материалов составь сжатый дайджест на русском языке.\n\n"
    "ТРЕБОВАНИЯ:\n"
    "1. Ровно 5–7 пунктов, самые значимые — первыми.\n"
    "2. Формат каждого пункта: <b>Короткий заголовок (до 8 слов)</b> — одно-два "
    "предложения сути и почему это важно.\n"
    "3. Только простые HTML-теги: <b>, <i>. Никакого Markdown, никаких # и **.\n"
    "4. Никаких вступлений, выводов, «вот дайджест» — только список пунктов.\n"
    "5. Английские названия компаний/моделей оставляй как есть.\n"
    "6. Не выдумывай факты, которых нет в заголовках."
)

JSON_BODY = (
    "={{ JSON.stringify({\n"
    "  model: 'llama-3.3-70b-versatile',\n"
    "  temperature: 0.35,\n"
    "  max_tokens: 1200,\n"
    "  messages: [\n"
    "    { role: 'system', content: " + json.dumps(LLM_SYSTEM, ensure_ascii=False) + " },\n"
    "    { role: 'user', content: 'Дата: ' + $json.date + '\\n\\nМатериалы за последние сутки:\\n\\n' + $json.listing }\n"
    "  ]\n"
    "}) }}"
)

RENDER_CODE = r"""// ── LLM-ответ → аккуратный HTML для Telegram + нарезка по 3800 символов ──
const llm = $input.first().json;
const agg = $('Собрать и почистить').first().json;

const text = String(llm?.choices?.[0]?.message?.content || '').trim();
if (!text) {
  return [{ json: { text: '⚠️ LLM вернула пустой ответ. Проверь ключ и лимиты модели.' } }];
}

const esc = s => String(s || '')
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

// Markdown-разметку, если модель всё же её выдала, приводим к HTML
let body = text
  .replace(/\r/g, '')
  .replace(/\*\*(.+?)\*\*/g, '<b>$1</b>')
  .replace(/^#{1,6}\s*/gm, '')
  .replace(/^\s*[-*•]\s+/gm, '• ')
  .replace(/^\s*(\d+)[.)]\s+/gm, '$1. ')
  .replace(/(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)/g, '<i>$1</i>');

// если модель отдала чистый текст — превратим строки в читаемые абзацы
if (!/<b>|<i>/.test(body)) {
  body = body.split(/\n{2,}/).map(p => p.trim()).filter(Boolean).join('\n\n');
}

const header = `<b>🤖 ИИ-дайджест — ${esc(agg.date)}</b>\n<i>${agg.count} материалов · TechCrunch, Hugging Face, GitHub, Habr, OpenAI</i>`;

const links = (agg.items || [])
  .slice(0, 8)
  .map((x, i) => `<a href="${esc(x.link)}">${i + 1}. ${esc(x.title.slice(0, 90))}</a>`)
  .join('\n');

const footer = links ? `\n\n<b>Ссылки</b>\n${links}` : '';

const full = `${header}\n\n${body}${footer}`;

// Telegram: лимит 4096 символов → режем по абзацам, не разрывая теги
const LIMIT = 3800;
const chunks = [];
if (full.length <= LIMIT) {
  chunks.push(full);
} else {
  const parts = full.split('\n');
  let buf = '';
  for (const line of parts) {
    if ((buf + '\n' + line).length > LIMIT && buf) { chunks.push(buf); buf = line; }
    else { buf = buf ? buf + '\n' + line : line; }
  }
  if (buf) chunks.push(buf);
}

return chunks.map(c => ({ json: { text: c } }));
"""

workflow = {
    "name": "AI Digest → Telegram (RSS + free LLM)",
    "nodes": [
        SCHEDULE,
        {
            "parameters": {},
            "id": "22222222-0000-4000-8000-000000000001",
            "name": "Sticky Note",
            "type": "n8n-nodes-base.stickyNote",
            "typeVersion": 1,
            "position": [-500, -120],
            "parameters_note": None,
        },
    ],
    "connections": {},
    "settings": {"executionOrder": "v1"},
    "pinData": {},
    "meta": {"templateCredsSetupCompleted": False},
}

# ── sticky note с инструкцией ──────────────────────────────────────────────
NOTE = """## Как запустить (5 минут)

**1. Ключ бесплатной LLM** — проще всего Groq (бесплатный тир, ~14 400 запросов/день):
- console.groq.com → API Keys → Create.
- Модель `llama-3.3-70b-versatile` (можно заменить на `llama-3.1-8b-instant` — быстрее).

**2. В ноде «LLM (Groq)»**:
- Credential → *Create new* → **Header Auth**
- Name: `Authorization`
- Value: `Bearer ВАШ_КЛЮЧ` ← именно с префиксом `Bearer `
- (Альтернатива без Groq: OpenRouter `https://openrouter.ai/api/v1/chat/completions`,
  модель `meta-llama/llama-3.3-70b-instruct:free`.)

**3. В ноде «Telegram»**:
- Credential → свой Telegram Bot Token (получить у @BotFather → /newbot).
- `chatId`: свой user id (узнать у @userinfobot) или `@ваш_канал`.

**4. Тест**: кнопка *Execute workflow*. Дальше — *Active* (переключатель сверху).
Расписание: каждые 3 часа. Меняется в ноде «Каждые 3 часа».

### Что где менять
- Источники → ноды `RSS: …`. Добавить свой = скопировать любую RSS-ноду и
  подключить к Merge (увеличив `Number of Inputs`).
- Окно свежести и число материалов → нода «Собрать и почистить» (`HOURS`, `MAX_ITEMS`).
- Тон и длина дайджеста → системный промпт в ноде «LLM (Groq)».
- Лимит Telegram 4096 символов уже учтён — длинный текст режется на части.

> Без LLM тоже работает: если ключа нет, можно выкинуть ноду LLM и подать
> в «Формат для Telegram» `$json.items` напрямую — получится просто список ссылок."""

workflow["nodes"] = [
    {
        "parameters": {"content": NOTE, "height": 520, "width": 480, "color": 4},
        "id": "22222222-0000-4000-8000-000000000001",
        "name": "Sticky Note",
        "type": "n8n-nodes-base.stickyNote",
        "typeVersion": 1,
        "position": [-1160, 80],
    },
    SCHEDULE,
]

# ── RSS-ноды ──────────────────────────────────────────────────────────────
for i, (name, url, y) in enumerate(FEEDS):
    workflow["nodes"].append({
        "parameters": {
            "url": url,
            "options": {"ignoreSSLIssues": False},
        },
        "id": f"33333333-0000-4000-8000-0000000000{i:02d}",
        "name": f"RSS: {name}",
        "type": "n8n-nodes-base.rssFeedRead",
        "typeVersion": 1.1,
        "position": [-40, 80 + i * 130],
        "alwaysOutputData": True,
    })

# ── Merge (append, 5 входов) ──────────────────────────────────────────────
workflow["nodes"].append({
    "parameters": {
        "numberInputs": len(FEEDS),
        "options": {},
    },
    "id": "44444444-0000-4000-8000-000000000001",
    "name": "Merge лент",
    "type": "n8n-nodes-base.merge",
    "typeVersion": 3,
    "position": [240, 380],
})

# ── Code: агрегация ───────────────────────────────────────────────────────
workflow["nodes"].append({
    "parameters": {"mode": "runOnceForAllItems", "jsCode": AGG_CODE},
    "id": "55555555-0000-4000-8000-000000000001",
    "name": "Собрать и почистить",
    "type": "n8n-nodes-base.code",
    "typeVersion": 2,
    "position": [480, 380],
})

# ── IF: есть ли что отправлять ────────────────────────────────────────────
workflow["nodes"].append({
    "parameters": {
        "conditions": {
            "options": {"caseSensitive": True, "leftValue": "", "typeValidation": "loose", "version": 2},
            "conditions": [
                {
                    "id": "c1",
                    "leftValue": "={{ $json.empty }}",
                    "rightValue": "",
                    "operator": {"type": "boolean", "operation": "notTrue", "singleValue": True},
                }
            ],
            "combinator": "and",
        },
        "options": {},
    },
    "id": "66666666-0000-4000-8000-000000000001",
    "name": "Есть новости?",
    "type": "n8n-nodes-base.if",
    "typeVersion": 2.2,
    "position": [720, 380],
})

# ── HTTP Request: Groq ────────────────────────────────────────────────────
workflow["nodes"].append({
    "parameters": {
        "method": "POST",
        "url": "https://api.groq.com/openai/v1/chat/completions",
        "authentication": "genericCredentialType",
        "genericAuthType": "httpHeaderAuth",
        "sendBody": True,
        "specifyBody": "json",
        "jsonBody": JSON_BODY,
        "options": {"timeout": 120000, "response": {"response": {"neverError": False}}},
    },
    "id": "77777777-0000-4000-8000-000000000001",
    "name": "LLM (Groq)",
    "type": "n8n-nodes-base.httpRequest",
    "typeVersion": 4.2,
    "position": [980, 280],
    "retryOnFail": True,
    "maxTries": 3,
    "waitBetweenTries": 3000,
})

# ── Code: рендер ──────────────────────────────────────────────────────────
workflow["nodes"].append({
    "parameters": {"mode": "runOnceForAllItems", "jsCode": RENDER_CODE},
    "id": "88888888-0000-4000-8000-000000000001",
    "name": "Формат для Telegram",
    "type": "n8n-nodes-base.code",
    "typeVersion": 2,
    "position": [1220, 280],
})

# ── Telegram ──────────────────────────────────────────────────────────────
workflow["nodes"].append({
    "parameters": {
        "chatId": "REPLACE_WITH_YOUR_CHAT_ID",
        "text": "={{ $json.text }}",
        "additionalFields": {
            "appendAttribution": False,
            "parse_mode": "HTML",
            "disable_web_page_preview": True,
        },
    },
    "id": "99999999-0000-4000-8000-000000000001",
    "name": "Telegram",
    "type": "n8n-nodes-base.telegram",
    "typeVersion": 1.2,
    "position": [1460, 280],
    "retryOnFail": True,
    "maxTries": 2,
    "waitBetweenTries": 2000,
})

# ── connections ───────────────────────────────────────────────────────────
conns = {}
for i, (name, url, y) in enumerate(FEEDS):
    conns[f"RSS: {name}"] = {"main": [[{"node": "Merge лент", "type": "main", "index": i}]]}

merge_conns = [{"node": "Merge лент", "type": "main", "index": i} for i in range(len(FEEDS))]
conns["Merge лент"] = {"main": [[{"node": "Собрать и почистить", "type": "main", "index": 0}]]}
conns["Каждые 3 часа"] = {"main": [[
    {"node": f"RSS: {n}", "type": "main", "index": 0} for n, u, y in FEEDS
]]}
conns["Собрать и почистить"] = {"main": [[{"node": "Есть новости?", "type": "main", "index": 0}]]}
conns["Есть новости?"] = {"main": [
    [{"node": "LLM (Groq)", "type": "main", "index": 0}],
    [],
]}
conns["LLM (Groq)"] = {"main": [[{"node": "Формат для Telegram", "type": "main", "index": 0}]]}
conns["Формат для Telegram"] = {"main": [[{"node": "Telegram", "type": "main", "index": 0}]]}

workflow["connections"] = conns

# Merge node inputs need explicit count also via numberInputs param (already set)

with open(OUT, "w", encoding="utf-8") as f:
    json.dump(workflow, f, ensure_ascii=False, indent=2)

# ── валидация ─────────────────────────────────────────────────────────────
data = json.load(open(OUT, encoding="utf-8"))
nodes = {n["name"] for n in data["nodes"]}
missing = [c for src, v in data["connections"].items()
           if src not in nodes for t in v["main"] for c in t if c["node"] not in nodes]
assert not missing, missing
assert len(data["nodes"]) == 13, len(data["nodes"])
print(f"ok → {OUT}")
print("nodes:", len(data["nodes"]), "| connections:", len(data["connections"]))
